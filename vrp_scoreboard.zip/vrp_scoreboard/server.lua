local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")

vRPSsb = {}
Tunnel.bindInterface("vRP_scoreboard",vRPSsb)
Proxy.addInterface("vRP_scoreboard",vRPSsb)

vRPCsb = Tunnel.getInterface("vRP_scoreboard","vRP_scoreboard")

onlinePlayers = {}


------- REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA


ems = 0
police = 0
fbi = 0
hitman = 0
uber = 0
curve = 0
mechanic = 0

function initPlayer(thePlayer, user_id)
	faction = "Civil"
	isAdmin = 0
	local isVip = 0
	playerName = "Nume"

	local thePlayer = vRP.getUserSource({user_id})
	
	if(vRP.hasGroup({user_id,"fondator"})) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isAdmin = 1
	end
	if(vRP.hasGroup({user_id,"dev"})) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isAdmin = 3
	end
	if(vRP.hasGroup({user_id,"superadmin"}) or vRP.hasGroup({user_id,"admin"}) or vRP.hasGroup({user_id,"helper"}) or vRP.hasGroup({user_id,"moderator"}))then              --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isAdmin = 2
	end
	if(vRP.hasGroup({user_id,"vip1"}))then              --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isVip = 3
	elseif(vRP.hasGroup({user_id,"vip2"}))  then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isVip = 2
	elseif(vRP.hasGroup({user_id,"vip3"})) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		isVip = 1
	end
	if vRP.hasGroup({user_id,"ems"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		faction = "Medici"
		ems = ems + 1
	elseif vRP.hasGroup({user_id,"FBI Agent"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		faction = "FBI"
		police = police + 1
	elseif vRP.hasGroup({user_id,"cop"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		faction = "Politie"
		police = police + 1
	end
	
	playerName = vRP.getPlayerName({thePlayer})
	
	if(playerName)then
		if(string.len(playerName)>14)then
			newPlayerName = ""
			for i = 1, string.len(playerName) do
				if(i <= 14)then
					newPlayerName = newPlayerName..string.sub(playerName, i, i)
				end
			end
			playerName = newPlayerName.."..."
		end
	end

	
	job = vRP.getUserGroupByType({user_id, "job"})
	if job == nil or job == "" then
		job = "Somer"
	end
	onlinePlayers[user_id] = {tostring(faction), tonumber(isAdmin), tonumber(isVip), tostring(playerName),tonumber(ore), tostring(job)}
	
	vRPCsb.initJobs(-1, {ems, police, jandarm})
	vRPCsb.initOnlinePlayers(-1, {onlinePlayers})
end


function uninitPlayer(user_id, thePlayer)
	if vRP.hasGroup({user_id,"ems"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		ems = ems - 1
	elseif vRP.hasGroup({user_id,"cop"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		police = police - 1
	elseif vRP.hasGroup({user_id,"jandarm"}) then             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
		police = police - 1
	end
	
	vRPCsb.initJobs(-1, {ems, police, jandarm})             --///REPLACE WITH YOUR GROUPS FROM VRP/CFG/GROUPS.LUA
	
	onlinePlayers[user_id] = nil
	vRPCsb.initOnlinePlayers(-1, {onlinePlayers})
end

local function fixScoreBoard()
	onlinePlayers = {}
	ems = 0
	police = 0
	users = vRP.getUsers({})
	for i, v in pairs(users) do
		thePlayer = v
		user_id = tonumber(i)

		if vRP.getPlayerName({thePlayer}) ~= "unknown" and vRP.getPlayerName({thePlayer}) ~= "Username" and vRP.getPlayerName({thePlayer}) then
			initPlayer(thePlayer, user_id)
		end
	end
end

RegisterCommand("deluser", function(player, args)
	local user_id = vRP.getUserId({player})

	if vRP.isUserTrialHelper({user_id}) then
		local target_id = parseInt(args[1])
		if target_id then
			vRP.request({player, "Esti sigur ca id "..target_id.." are unknown ?", 15, function(player, ok)
				if ok then
					vRP.deleteOnlineUser({target_id})
					fixScoreBoard()
					TriggerClientEvent("chatMessage", player, "^1Deleted^7: Id ^1"..target_id.." ^7a fost sters din scoreboard")
				end
			end})
		else
			TriggerClientEvent("chatMessage", player, "^1Syntax^7: /deluser <user_id>")
		end
	else 
		TriggerClientEvent("chatMessage", player, "^1Eroare^7: Nu ai acces la aceasta comanda")
	end
end)

Citizen.CreateThread(function()
	while true do
		fixScoreBoard()
		Citizen.Wait(5 * 60 * 1000)
	end
end)

RegisterCommand("fixscoreboard", function() fixScoreBoard() end)


AddEventHandler("vRP:playerSpawn",function(user_id, source, first_spawn)
	initPlayer(source, user_id)
end)

AddEventHandler("vRP:playerLeave", function(user_id, source)
	if onlinePlayers[user_id] ~= nil then
		uninitPlayer(user_id, source)
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(20000)
		fixScoreBoard()
	end
end)